ALTER TABLE member ADD COLUMN assigned_colors TEXT;
