ALTER TABLE member DROP COLUMN vip_expires_at;
