DROP TABLE IF EXISTS buddhist_days;
