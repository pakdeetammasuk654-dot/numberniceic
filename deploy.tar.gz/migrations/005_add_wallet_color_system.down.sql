DROP TABLE IF EXISTS wallet_colors;
ALTER TABLE member DROP COLUMN IF EXISTS day_of_birth;
